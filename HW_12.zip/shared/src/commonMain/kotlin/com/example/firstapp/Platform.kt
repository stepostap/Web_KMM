package com.example.firstapp

expect class Platform() {
    val platform: String
}