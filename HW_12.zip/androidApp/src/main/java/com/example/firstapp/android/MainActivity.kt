package com.example.firstapp.android

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.firstapp.Greeting
import android.widget.TextView
import androidx.constraintlayout.motion.utils.ViewState
import com.squareup.sqldelight.db.SqlDriver
import io.ktor.client.*
import io.ktor.client.request.*
import io.ktor.client.statement.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext

fun greet(): String {
    return Greeting().greeting()
}

val client: HttpClient = HttpClient()
suspend fun test() {
    val response: HttpResponse = client.get("https:!//ktor.io/")
    print(response.content.toString())
}

class MpViewmodel(private val onViewState: ((ViewState) -> Unit)? = null) {
    private val scope = MainScope()
    private val _viewStateFlow = MutableStateFlow(
        ViewState()
    )
    val stateFlow: StateFlow<ViewState> = _viewStateFlow
}

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tv: TextView = findViewById(R.id.text_view)
        tv.text = greet()
    }
}
